#!/usr/bin/env bash
# Passt das generierte Android-Projekt an: Kamera-/Internet-Rechte und minSdk 24.
set -e
MANIFEST=android/app/src/main/AndroidManifest.xml
if ! grep -q "android.permission.CAMERA" "$MANIFEST"; then
  sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA"/>\n    <uses-permission android:name="android.permission.INTERNET"/>\n    <application#' "$MANIFEST"
fi
for f in android/app/build.gradle android/app/build.gradle.kts; do
  if [ -f "$f" ]; then
    sed -i -E 's/minSdk(Version)?[ =]+flutter\.minSdkVersion/minSdk = 24/' "$f"
  fi
done
echo "Android konfiguriert."

# Lint-Prüfung der Plugins abschalten (Lint-Absturz in camera_android_camerax).
mkdir -p "$HOME/.gradle/init.d"
cat > "$HOME/.gradle/init.d/no-lint.gradle" <<'EOG'
allprojects {
  tasks.configureEach { t ->
    if (t.name.startsWith('lint')) {
      t.enabled = false
    }
  }
}
EOG
echo "Lint deaktiviert."
