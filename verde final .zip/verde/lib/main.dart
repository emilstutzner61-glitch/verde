import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';
import 'screens/onboarding_screen.dart';
import 'screens/shell.dart';
import 'services/household_service.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: firebaseOptions);
  if (FirebaseAuth.instance.currentUser == null) {
    await FirebaseAuth.instance.signInAnonymously();
  }
  await HouseholdService.instance.load();
  runApp(const VerdeApp());
}

class VerdeApp extends StatelessWidget {
  const VerdeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Verde',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: ListenableBuilder(
        listenable: HouseholdService.instance,
        builder: (_, __) => HouseholdService.instance.code == null
            ? const OnboardingScreen()
            : const Shell(),
      ),
    );
  }
}
