import 'package:flutter/material.dart';

class Pal {
  // Luxus-Modus
  static const green = Color(0xFF0E3B2E);
  static const greenDeep = Color(0xFF082A20);
  static const greenSoft = Color(0xFFE3ECE7);
  static const bg = Color(0xFFF6F7F5);
  static const ink = Color(0xFF1C201E);
  static const grey = Color(0xFF8B928E);
  static const line = Color(0xFFE3E6E3);
  // HUD-Modus
  static const hudBg = Color(0xFF02090D);
  static const hudCyan = Color(0xFF3DDCFF);
  static const hudGold = Color(0xFFFFB347);
  static const hudRed = Color(0xFFFF4D4D);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: Pal.green,
    brightness: Brightness.light,
  ).copyWith(
    primary: Pal.green,
    onPrimary: Colors.white,
    surface: Colors.white,
    onSurface: Pal.ink,
    secondary: Pal.greenSoft,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: Pal.bg,
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: Pal.green,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: Pal.green,
        minimumSize: const Size.fromHeight(52),
        side: const BorderSide(color: Pal.line),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Pal.line),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Pal.line),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Pal.green, width: 1.4),
      ),
    ),
  );
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(16)});

  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Pal.line),
        ),
        child: child,
      );
}

class ScreenTitle extends StatelessWidget {
  final String title;
  final String? subtitle;
  const ScreenTitle(this.title, {super.key, this.subtitle});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 12, 4, 20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: const TextStyle(
                  fontSize: 30, fontWeight: FontWeight.w300, letterSpacing: -0.5, color: Pal.ink)),
          if (subtitle != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(subtitle!, style: const TextStyle(color: Pal.grey, fontSize: 14)),
            ),
        ]),
      );
}

String cap(String s) => s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
