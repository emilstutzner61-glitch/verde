import 'package:firebase_core/firebase_core.dart';

/// Werte aus der google-services.json (Android-App de.verde.verde).
const firebaseOptions = FirebaseOptions(
  apiKey: 'AIzaSyAjLnKsFIkeRC38bZy1ONAP_oxbelvc6Xw',
  appId: '1:49787465205:android:075547a53040757625c4bc',
  messagingSenderId: '49787465205',
  projectId: 'foodscan-ai-1ab12',
);
