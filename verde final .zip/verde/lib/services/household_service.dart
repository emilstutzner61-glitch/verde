import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FridgeItem {
  final String id, name, amount, addedBy;
  FridgeItem(this.id, this.name, this.amount, this.addedBy);
}

class ShopItem {
  final String id, name, addedBy;
  final bool done;
  ShopItem(this.id, this.name, this.done, this.addedBy);
}

/// Gemeinsamer Haushalt in Firestore:
/// households/{CODE}            -> { members: [...] }
/// households/{CODE}/fridge/*   -> { name, amount, addedBy }
/// households/{CODE}/shopping/* -> { name, done, addedBy }
class HouseholdService extends ChangeNotifier {
  HouseholdService._();
  static final HouseholdService instance = HouseholdService._();

  FirebaseFirestore get _db => FirebaseFirestore.instance;
  String? code;
  String memberName = '';

  DocumentReference<Map<String, dynamic>> get _doc => _db.collection('households').doc(code);
  CollectionReference<Map<String, dynamic>> get _fridge => _doc.collection('fridge');
  CollectionReference<Map<String, dynamic>> get _shop => _doc.collection('shopping');

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    code = p.getString('code');
    memberName = p.getString('name') ?? '';
  }

  Future<void> _save(String c, String name) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('code', c);
    await p.setString('name', name);
    code = c;
    memberName = name;
    notifyListeners();
  }

  static String _gen() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random.secure();
    return List.generate(6, (_) => chars[r.nextInt(chars.length)]).join();
  }

  Future<String> create(String name) async {
    String c;
    do {
      c = _gen();
    } while ((await _db.collection('households').doc(c).get()).exists);
    await _db.collection('households').doc(c).set({
      'createdAt': FieldValue.serverTimestamp(),
      'members': [name],
    });
    await _save(c, name);
    return c;
  }

  Future<bool> join(String input, String name) async {
    final ref = _db.collection('households').doc(input.trim().toUpperCase());
    final snap = await ref.get();
    if (!snap.exists) return false;
    await ref.update({'members': FieldValue.arrayUnion([name])});
    await _save(ref.id, name);
    return true;
  }

  Future<void> leave() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('code');
    code = null;
    notifyListeners();
  }

  Stream<List<String>> membersStream() => _doc
      .snapshots()
      .map((d) => List<String>.from((d.data()?['members'] ?? []) as List));

  // ---------- Kühlschrank ----------
  Stream<List<FridgeItem>> fridgeStream() => _fridge.snapshots().map((q) {
        final l = q.docs.map((d) {
          final m = d.data();
          return FridgeItem(d.id, (m['name'] as String?) ?? '',
              (m['amount'] as String?) ?? '', (m['addedBy'] as String?) ?? '');
        }).toList();
        l.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        return l;
      });

  Future<void> addFridge(String name, {String amount = ''}) => _fridge.add({
        'name': name,
        'amount': amount,
        'addedBy': memberName,
        'at': FieldValue.serverTimestamp(),
      });

  Future<void> deleteFridge(String id) => _fridge.doc(id).delete();

  // ---------- Einkaufsliste ----------
  Stream<List<ShopItem>> shoppingStream() => _shop.snapshots().map((q) {
        final l = q.docs.map((d) {
          final m = d.data();
          return ShopItem(d.id, (m['name'] as String?) ?? '', (m['done'] as bool?) ?? false,
              (m['addedBy'] as String?) ?? '');
        }).toList();
        l.sort((a, b) {
          if (a.done != b.done) return a.done ? 1 : -1;
          return a.name.toLowerCase().compareTo(b.name.toLowerCase());
        });
        return l;
      });

  Future<void> addShopping(String name) => _shop.add({
        'name': name,
        'done': false,
        'addedBy': memberName,
        'at': FieldValue.serverTimestamp(),
      });

  Future<void> toggleShopping(String id, bool done) => _shop.doc(id).update({'done': done});

  Future<void> deleteShopping(String id) => _shop.doc(id).delete();

  Future<void> clearDone() async {
    final q = await _shop.where('done', isEqualTo: true).get();
    final batch = _db.batch();
    for (final d in q.docs) {
      batch.delete(d.reference);
    }
    await batch.commit();
  }
}
