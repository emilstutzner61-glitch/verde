class Recipe {
  final String title, emoji;
  final int tempC, minutes;
  final List<String> ingredients; // Schlüsselwörter, kleingeschrieben
  final List<String> steps;
  const Recipe(this.title, this.emoji, this.tempC, this.minutes, this.ingredients, this.steps);

  bool _has(String ing, List<String> fridge) =>
      fridge.any((f) => f.contains(ing) || ing.contains(f));

  List<String> have(List<String> fridge) => ingredients.where((i) => _has(i, fridge)).toList();
  List<String> missing(List<String> fridge) => ingredients.where((i) => !_has(i, fridge)).toList();
}

// Salz, Pfeffer, Öl und Gewürze werden als vorhanden angenommen.
const airfryerRecipes = <Recipe>[
  Recipe('Hähnchenschenkel & Kartoffelspalten', '🍗', 200, 30, ['hähnchen', 'kartoffel'], [
    'Schenkel mit Öl, Salz, Paprikapulver einreiben.',
    'Kartoffeln in Spalten schneiden und mit Öl mischen.',
    'Alles in den Korb, nach 15 Min. wenden.',
  ]),
  Recipe('Gebackener Käse mit Honig', '🧀', 180, 8, ['käse'], [
    'Käse (z. B. Camembert) mehrfach einritzen.',
    'Mit Honig und Thymian beträufeln.',
    '8 Min. backen, mit Brot servieren.',
  ]),
  Recipe('Lachs mit Brokkoli', '🐟', 180, 12, ['fisch', 'brokkoli'], [
    'Fisch mit Zitrone, Salz und Öl würzen.',
    'Brokkoliröschen mit Öl mischen.',
    'Zusammen 12 Min. garen.',
  ]),
  Recipe('Gefüllte Paprika', '🫑', 180, 15, ['paprika', 'käse', 'zwiebel'], [
    'Paprika halbieren und entkernen.',
    'Zwiebel würfeln, mit Käse mischen und einfüllen.',
    '15 Min. garen, bis der Käse goldbraun ist.',
  ]),
  Recipe('Röstgemüse-Mix', '🥕', 190, 18, ['karotte', 'zucchini', 'zwiebel'], [
    'Gemüse in gleich große Stücke schneiden.',
    'Mit Öl, Salz und Kräutern mischen.',
    '18 Min. garen, zwischendurch schütteln.',
  ]),
  Recipe('Ei im Brot-Nest', '🍳', 180, 8, ['brot', 'ei', 'käse'], [
    'Brotscheibe mittig ausstechen, in die Form legen.',
    'Ei hineinschlagen, Käse darüberstreuen.',
    '8 Min. backen.',
  ]),
  Recipe('Bratwurst mit Zwiebeln', '🌭', 180, 12, ['wurst', 'zwiebel'], [
    'Zwiebeln in Ringe schneiden, mit Öl mischen.',
    'Würste einstechen und zu den Zwiebeln legen.',
    '12 Min. garen, einmal wenden.',
  ]),
  Recipe('Blumenkohl-Wings', '🥦', 200, 20, ['blumenkohl'], [
    'Röschen mit Öl, Paprikapulver und Salz marinieren.',
    '20 Min. knusprig garen, ab und zu schütteln.',
    'Mit einem Dip servieren.',
  ]),
  Recipe('Bratapfel', '🍎', 180, 12, ['apfel'], [
    'Kerngehäuse entfernen.',
    'Mit Zimt, Zucker und Nüssen füllen.',
    '12 Min. backen.',
  ]),
  Recipe('Gefüllte Champignons', '🍄', 180, 10, ['pilz', 'käse'], [
    'Stiele entfernen.',
    'Mit Käse und Kräutern füllen.',
    '10 Min. garen.',
  ]),
  Recipe('Knusprige Pommes', '🍟', 200, 20, ['kartoffel'], [
    'Kartoffeln in Stifte schneiden, 20 Min. wässern, trocknen.',
    'Mit Öl und Salz mischen.',
    '20 Min. garen, mehrfach schütteln.',
  ]),
];
