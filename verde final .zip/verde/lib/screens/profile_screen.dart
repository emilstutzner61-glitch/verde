import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/household_service.dart';
import '../theme.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _s = HouseholdService.instance;
  late final _members = _s.membersStream();

  Future<void> _leave() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Haushalt verlassen?'),
        content: const Text('Du kannst mit dem Code jederzeit wieder beitreten.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Abbrechen')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Verlassen')),
        ],
      ),
    );
    if (ok == true) await _s.leave();
  }

  @override
  Widget build(BuildContext context) {
    final initial = _s.memberName.isEmpty ? '?' : _s.memberName[0].toUpperCase();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          const ScreenTitle('Profil'),
          Center(
            child: CircleAvatar(
              radius: 40,
              backgroundColor: Pal.green,
              child: Text(initial,
                  style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w300)),
            ),
          ),
          const SizedBox(height: 14),
          Center(child: Text(_s.memberName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w400))),
          const SizedBox(height: 28),
          Panel(
            child: Row(children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('EINLADUNGSCODE',
                    style: TextStyle(color: Pal.grey, fontSize: 11, letterSpacing: 2)),
                const SizedBox(height: 6),
                Text(_s.code ?? '',
                    style: const TextStyle(fontSize: 28, letterSpacing: 8, fontWeight: FontWeight.w300)),
              ]),
              const Spacer(),
              IconButton(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: _s.code ?? ''));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Code kopiert')));
                },
                icon: const Icon(Icons.copy_rounded, color: Pal.green),
              ),
            ]),
          ),
          const SizedBox(height: 16),
          Panel(
            child: StreamBuilder<List<String>>(
              stream: _members,
              builder: (_, snap) {
                final m = snap.data ?? [];
                return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('MITGLIEDER', style: TextStyle(color: Pal.grey, fontSize: 11, letterSpacing: 2)),
                  const SizedBox(height: 10),
                  for (final n in m)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(children: [
                        const Icon(Icons.person_outline, size: 18, color: Pal.green),
                        const SizedBox(width: 10),
                        Text(n),
                      ]),
                    ),
                ]);
              },
            ),
          ),
          const SizedBox(height: 24),
          OutlinedButton(onPressed: _leave, child: const Text('Haushalt verlassen')),
        ],
      ),
    );
  }
}
