import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/household_service.dart';
import '../theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _s = HouseholdService.instance;
  late final _fridge = _s.fridgeStream();
  late final _shop = _s.shoppingStream();

  Future<void> _add() async {
    final name = TextEditingController();
    final amount = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Zum Kühlschrank', style: TextStyle(fontWeight: FontWeight.w300)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: name,
              autofocus: true,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(labelText: 'Lebensmittel')),
          const SizedBox(height: 12),
          TextField(controller: amount, decoration: const InputDecoration(labelText: 'Menge (optional)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Abbrechen')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Hinzufügen')),
        ],
      ),
    );
    if (ok == true && name.text.trim().isNotEmpty) {
      await _s.addFridge(name.text.trim(), amount: amount.text.trim());
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: StreamBuilder<List<FridgeItem>>(
        stream: _fridge,
        builder: (context, snap) {
          final items = snap.data ?? [];
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              ScreenTitle('Guten Tag${_s.memberName.isEmpty ? '' : ', ${_s.memberName}'}',
                  subtitle: 'Alles Frische im Blick'),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: const LinearGradient(
                    colors: [Pal.green, Pal.greenDeep],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('IM KÜHLSCHRANK',
                      style: TextStyle(color: Colors.white54, fontSize: 11, letterSpacing: 2.5)),
                  Text('${items.length}',
                      style: const TextStyle(
                          color: Colors.white, fontSize: 64, fontWeight: FontWeight.w200, height: 1.1)),
                  StreamBuilder<List<ShopItem>>(
                    stream: _shop,
                    builder: (_, s2) {
                      final open = (s2.data ?? []).where((e) => !e.done).length;
                      return Text('Artikel · $open offen auf der Einkaufsliste',
                          style: const TextStyle(color: Colors.white70, fontSize: 14));
                    },
                  ),
                  const SizedBox(height: 22),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.08), borderRadius: BorderRadius.circular(14)),
                    child: Row(children: [
                      const Icon(Icons.group_outlined, color: Colors.white70, size: 18),
                      const SizedBox(width: 10),
                      Text('Code  ${_s.code}',
                          style: const TextStyle(color: Colors.white, letterSpacing: 3, fontSize: 14)),
                      const Spacer(),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(ClipboardData(text: _s.code ?? ''));
                          ScaffoldMessenger.of(context)
                              .showSnackBar(const SnackBar(content: Text('Code kopiert')));
                        },
                        child: const Icon(Icons.copy_rounded, color: Colors.white70, size: 18),
                      ),
                    ]),
                  ),
                ]),
              ),
              const SizedBox(height: 28),
              Row(children: [
                const Text('Inventar', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w400)),
                const Spacer(),
                TextButton.icon(
                  onPressed: _add,
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Hinzufügen'),
                  style: TextButton.styleFrom(foregroundColor: Pal.green),
                ),
              ]),
              const SizedBox(height: 8),
              if (items.isEmpty)
                const Panel(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'Noch leer. Füge Lebensmittel hinzu oder nutze den Scanner.',
                    style: TextStyle(color: Pal.grey, height: 1.4),
                  ),
                ),
              for (final i in items)
                Dismissible(
                  key: ValueKey(i.id),
                  direction: DismissDirection.endToStart,
                  onDismissed: (_) => _s.deleteFridge(i.id),
                  background: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration:
                        BoxDecoration(color: Pal.greenSoft, borderRadius: BorderRadius.circular(18)),
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 24),
                    child: const Icon(Icons.delete_outline, color: Pal.green),
                  ),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Pal.line),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
                      title: Text(cap(i.name), style: const TextStyle(fontWeight: FontWeight.w500)),
                      subtitle: Text(
                        [if (i.amount.isNotEmpty) i.amount, if (i.addedBy.isNotEmpty) 'von ${i.addedBy}']
                            .join(' · '),
                        style: const TextStyle(color: Pal.grey, fontSize: 12),
                      ),
                      trailing: const Icon(Icons.chevron_left, color: Pal.line),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
