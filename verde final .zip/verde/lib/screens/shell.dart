import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme.dart';
import 'home_screen.dart';
import 'profile_screen.dart';
import 'recipes_screen.dart';
import 'scanner_screen.dart';
import 'shopping_screen.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;
  static const _scannerIndex = 3;

  Widget _page() {
    switch (_i) {
      case 0:
        return const HomeScreen();
      case 1:
        return const ShoppingScreen();
      case 2:
        return const RecipesScreen();
      case 3:
        // Wird nur gebaut, wenn der Tab aktiv ist -> Kamera startet/stoppt sauber.
        return const ScannerScreen();
      default:
        return const ProfileScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    final hud = _i == _scannerIndex;
    final selectedColor = hud ? Pal.hudCyan : Pal.green;
    final idleColor = hud ? Colors.white54 : Pal.grey;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: hud ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
      child: Scaffold(
        backgroundColor: hud ? Pal.hudBg : Pal.bg,
        body: AnimatedSwitcher(
          duration: const Duration(milliseconds: 400),
          child: KeyedSubtree(key: ValueKey(_i), child: _page()),
        ),
        bottomNavigationBar: AnimatedContainer(
          duration: const Duration(milliseconds: 400),
          decoration: BoxDecoration(
            color: hud ? Pal.hudBg : Colors.white,
            border: Border(
              top: BorderSide(color: hud ? Pal.hudCyan.withOpacity(0.35) : Pal.line),
            ),
          ),
          child: NavigationBarTheme(
            data: NavigationBarThemeData(
              backgroundColor: Colors.transparent,
              surfaceTintColor: Colors.transparent,
              elevation: 0,
              indicatorColor: hud ? Pal.hudCyan.withOpacity(0.16) : Pal.greenSoft,
              iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
                    color: s.contains(WidgetState.selected) ? selectedColor : idleColor,
                  )),
              labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
                    fontSize: 11,
                    letterSpacing: hud ? 1.2 : 0.2,
                    fontFamily: hud ? 'monospace' : null,
                    color: s.contains(WidgetState.selected) ? selectedColor : idleColor,
                  )),
            ),
            child: NavigationBar(
              selectedIndex: _i,
              onDestinationSelected: (v) => setState(() => _i = v),
              destinations: const [
                NavigationDestination(
                    icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
                NavigationDestination(
                    icon: Icon(Icons.checklist_outlined),
                    selectedIcon: Icon(Icons.checklist),
                    label: 'Einkauf'),
                NavigationDestination(
                    icon: Icon(Icons.menu_book_outlined),
                    selectedIcon: Icon(Icons.menu_book),
                    label: 'Rezepte'),
                NavigationDestination(
                    icon: Icon(Icons.center_focus_weak_outlined),
                    selectedIcon: Icon(Icons.center_focus_strong),
                    label: 'Scanner'),
                NavigationDestination(
                    icon: Icon(Icons.person_outline),
                    selectedIcon: Icon(Icons.person),
                    label: 'Profil'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
