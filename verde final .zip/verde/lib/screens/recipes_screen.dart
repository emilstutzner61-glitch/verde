import 'package:flutter/material.dart';

import '../services/household_service.dart';
import '../services/recipes.dart';
import '../theme.dart';

class _Scored {
  final Recipe r;
  final List<String> have, missing;
  _Scored(this.r, this.have, this.missing);
  double get ratio => r.ingredients.isEmpty ? 0 : have.length / r.ingredients.length;
}

class RecipesScreen extends StatefulWidget {
  const RecipesScreen({super.key});

  @override
  State<RecipesScreen> createState() => _RecipesScreenState();
}

class _RecipesScreenState extends State<RecipesScreen> {
  final _s = HouseholdService.instance;
  late final _stream = _s.fridgeStream();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: StreamBuilder<List<FridgeItem>>(
        stream: _stream,
        builder: (context, snap) {
          final fridge = (snap.data ?? []).map((e) => e.name.toLowerCase()).toList();
          final scored = airfryerRecipes
              .map((r) => _Scored(r, r.have(fridge), r.missing(fridge)))
              .toList()
            ..sort((a, b) => b.ratio.compareTo(a.ratio));

          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              const ScreenTitle('Airfryer-Rezepte', subtitle: 'Passend zu deinem Kühlschrank'),
              for (final s in scored)
                Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: Pal.line),
                  ),
                  child: Theme(
                    data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                    child: ExpansionTile(
                      tilePadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
                      childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
                      shape: const Border(),
                      collapsedShape: const Border(),
                      leading: Text(s.r.emoji, style: const TextStyle(fontSize: 28)),
                      title: Text(s.r.title, style: const TextStyle(fontWeight: FontWeight.w500)),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${s.r.tempC} °C · ${s.r.minutes} Min. · ${s.have.length}/${s.r.ingredients.length} Zutaten',
                              style: const TextStyle(color: Pal.grey, fontSize: 12)),
                          const SizedBox(height: 8),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: s.ratio,
                              minHeight: 4,
                              backgroundColor: Pal.greenSoft,
                              color: Pal.green,
                            ),
                          ),
                        ]),
                      ),
                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Wrap(spacing: 8, runSpacing: 8, children: [
                            for (final i in s.r.ingredients)
                              Chip(
                                label: Text(cap(i), style: const TextStyle(fontSize: 12)),
                                backgroundColor: s.have.contains(i) ? Pal.greenSoft : Colors.white,
                                side: BorderSide(color: s.have.contains(i) ? Pal.greenSoft : Pal.line),
                                avatar: Icon(
                                  s.have.contains(i) ? Icons.check : Icons.add,
                                  size: 14,
                                  color: s.have.contains(i) ? Pal.green : Pal.grey,
                                ),
                              ),
                          ]),
                        ),
                        const SizedBox(height: 14),
                        for (var n = 0; n < s.r.steps.length; n++)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('${n + 1}.  ', style: const TextStyle(color: Pal.green, fontWeight: FontWeight.w600)),
                              Expanded(child: Text(s.r.steps[n], style: const TextStyle(height: 1.4))),
                            ]),
                          ),
                        if (s.missing.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          OutlinedButton.icon(
                            onPressed: () async {
                              for (final m in s.missing) {
                                await _s.addShopping(cap(m));
                              }
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Fehlendes auf die Einkaufsliste gesetzt')));
                              }
                            },
                            icon: const Icon(Icons.add_shopping_cart, size: 18),
                            label: const Text('Fehlendes einkaufen'),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
