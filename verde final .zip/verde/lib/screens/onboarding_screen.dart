import 'package:flutter/material.dart';

import '../services/household_service.dart';
import '../theme.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _name = TextEditingController();
  final _code = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _code.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function() job) async {
    if (_name.text.trim().isEmpty) {
      setState(() => _error = 'Bitte gib zuerst deinen Namen ein.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await job();
    } catch (e) {
      if (mounted) setState(() => _error = 'Verbindung fehlgeschlagen. Prüfe Internet und Firebase-Einrichtung.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _create() => _run(() async {
        await HouseholdService.instance.create(_name.text.trim());
      });

  Future<void> _join() => _run(() async {
        final ok = await HouseholdService.instance.join(_code.text, _name.text.trim());
        if (!ok && mounted) setState(() => _error = 'Diesen Haushalts-Code gibt es nicht.');
      });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(28, 48, 28, 28),
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(color: Pal.green, borderRadius: BorderRadius.circular(20)),
              child: const Icon(Icons.eco_outlined, color: Colors.white, size: 30),
            ),
            const SizedBox(height: 28),
            const Text('Willkommen\nbei Verde',
                style: TextStyle(fontSize: 38, fontWeight: FontWeight.w300, height: 1.1, letterSpacing: -1)),
            const SizedBox(height: 10),
            const Text('Ein Kühlschrank. Eine Einkaufsliste.\nFür die ganze Familie in Echtzeit.',
                style: TextStyle(color: Pal.grey, fontSize: 15, height: 1.4)),
            const SizedBox(height: 36),
            TextField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'Dein Name'),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _busy ? null : _create,
              child: const Text('Neuen Haushalt erstellen'),
            ),
            const SizedBox(height: 28),
            const Row(children: [
              Expanded(child: Divider(color: Pal.line)),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Text('ODER', style: TextStyle(color: Pal.grey, fontSize: 11, letterSpacing: 2)),
              ),
              Expanded(child: Divider(color: Pal.line)),
            ]),
            const SizedBox(height: 28),
            TextField(
              controller: _code,
              textCapitalization: TextCapitalization.characters,
              maxLength: 6,
              style: const TextStyle(letterSpacing: 6, fontWeight: FontWeight.w500),
              decoration: const InputDecoration(labelText: 'Einladungscode', counterText: ''),
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: _busy ? null : _join,
              child: const Text('Haushalt beitreten'),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 18),
                child: Text(_error!, style: const TextStyle(color: Color(0xFF9B3B3B))),
              ),
            if (_busy)
              const Padding(
                padding: EdgeInsets.only(top: 24),
                child: Center(child: CircularProgressIndicator(color: Pal.green, strokeWidth: 2)),
              ),
          ],
        ),
      ),
    );
  }
}
