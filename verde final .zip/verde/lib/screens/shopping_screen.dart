import 'package:flutter/material.dart';

import '../services/household_service.dart';
import '../theme.dart';

class ShoppingScreen extends StatefulWidget {
  const ShoppingScreen({super.key});

  @override
  State<ShoppingScreen> createState() => _ShoppingScreenState();
}

class _ShoppingScreenState extends State<ShoppingScreen> {
  final _s = HouseholdService.instance;
  late final _stream = _s.shoppingStream();
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    _ctrl.clear();
    await _s.addShopping(t);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: StreamBuilder<List<ShopItem>>(
        stream: _stream,
        builder: (context, snap) {
          final items = snap.data ?? [];
          final hasDone = items.any((e) => e.done);
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              const ScreenTitle('Einkaufsliste', subtitle: 'Gemeinsam, live aktualisiert'),
              TextField(
                controller: _ctrl,
                textCapitalization: TextCapitalization.sentences,
                onSubmitted: (_) => _add(),
                decoration: InputDecoration(
                  hintText: 'Artikel hinzufügen',
                  suffixIcon: IconButton(
                    onPressed: _add,
                    icon: const Icon(Icons.add_circle_outline, color: Pal.green),
                  ),
                ),
              ),
              if (hasDone)
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: _s.clearDone,
                    style: TextButton.styleFrom(foregroundColor: Pal.green),
                    child: const Text('Erledigte entfernen'),
                  ),
                ),
              const SizedBox(height: 8),
              if (items.isEmpty)
                const Panel(
                  padding: EdgeInsets.all(24),
                  child: Text('Die Liste ist leer.', style: TextStyle(color: Pal.grey)),
                ),
              for (final i in items)
                Dismissible(
                  key: ValueKey(i.id),
                  direction: DismissDirection.endToStart,
                  onDismissed: (_) => _s.deleteShopping(i.id),
                  background: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration:
                        BoxDecoration(color: Pal.greenSoft, borderRadius: BorderRadius.circular(18)),
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 24),
                    child: const Icon(Icons.delete_outline, color: Pal.green),
                  ),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Pal.line),
                    ),
                    child: CheckboxListTile(
                      value: i.done,
                      onChanged: (v) => _s.toggleShopping(i.id, v ?? false),
                      activeColor: Pal.green,
                      controlAffinity: ListTileControlAffinity.leading,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      title: Text(
                        cap(i.name),
                        style: TextStyle(
                          decoration: i.done ? TextDecoration.lineThrough : null,
                          color: i.done ? Pal.grey : Pal.ink,
                        ),
                      ),
                      subtitle: i.addedBy.isEmpty
                          ? null
                          : Text('von ${i.addedBy}', style: const TextStyle(fontSize: 12, color: Pal.grey)),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
