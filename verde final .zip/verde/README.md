# Verde – Familien-Kühlschrank (Flutter)

Luxus-Modus (Dunkelgrün/Weiß/Grau) + Sci-Fi-HUD im Scanner-Tab.

## Einrichtung (einmalig)

1. **Firebase-Projekt** anlegen (console.firebase.google.com).
2. **Android-App** hinzufügen mit Paketname `de.verde.verde`.
3. **Authentication** → Anmeldemethode → *Anonym* aktivieren.
4. **Firestore** erstellen und unter *Regeln* einfügen:
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{db}/documents {
       match /households/{code}/{document=**} {
         allow read, write: if request.auth != null;
       }
       match /households/{code} {
         allow read, write: if request.auth != null;
       }
     }
   }
   ```
5. In `lib/firebase_options.dart` die vier Werte aus der `google-services.json` eintragen
   (`current_key`, `mobilesdk_app_id`, `project_number`, `project_id`).

## APK über GitHub bauen

Repo pushen (Branch `main`) → Tab **Actions** → *Build APK* → fertige `verde-apk` unter *Artifacts*.
Lokal: `flutter create --platforms=android --project-name verde --org de.verde . && bash tool/configure_android.sh && flutter run`

## Hinweise

- Die Erkennung nutzt Google ML Kit (on-device). Sie liefert Labels, keine Bounding-Boxes;
  das HUD zeigt daher einen festen Zielrahmen. Für präzisere Erkennung später ein eigenes TFLite-Modell einbinden.
- Die Regeln oben sind bewusst einfach: Wer den Code kennt, kommt in den Haushalt. Für mehr Sicherheit Regeln pro Mitglied verschärfen.
