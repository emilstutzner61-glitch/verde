import 'dart:async';
import 'dart:math';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';

import '../services/food_labels.dart';
import '../services/household_service.dart';
import '../theme.dart';

class _Det {
  final double conf;
  final DateTime seen;
  _Det(this.conf, this.seen);
}

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _anim =
      AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
  final _labeler = ImageLabeler(options: ImageLabelerOptions(confidenceThreshold: 0.55));
  final _s = HouseholdService.instance;

  CameraController? _cam;
  String? _error;
  final Map<String, _Det> _dets = {};
  final Set<String> _added = {};
  bool _busy = false;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);
  int _frames = 0;
  Timer? _pruner;

  @override
  void initState() {
    super.initState();
    _initCamera();
    _pruner = Timer.periodic(const Duration(milliseconds: 500), (_) {
      final cutoff = DateTime.now().subtract(const Duration(milliseconds: 2200));
      final before = _dets.length;
      _dets.removeWhere((_, d) => d.seen.isBefore(cutoff));
      if (mounted && before != _dets.length) setState(() {});
    });
  }

  Future<void> _initCamera() async {
    try {
      final cams = await availableCameras();
      final back = cams.firstWhere((c) => c.lensDirection == CameraLensDirection.back,
          orElse: () => cams.first);
      final ctrl = CameraController(
        back,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.nv21,
      );
      await ctrl.initialize();
      await ctrl.lockCaptureOrientation(DeviceOrientation.portraitUp);
      if (!mounted) {
        await ctrl.dispose();
        return;
      }
      await ctrl.startImageStream((img) => _onFrame(img, back));
      setState(() => _cam = ctrl);
    } catch (_) {
      if (mounted) setState(() => _error = 'KAMERA OFFLINE\nBitte Kamera-Berechtigung erteilen.');
    }
  }

  Future<void> _onFrame(CameraImage img, CameraDescription cam) async {
    final now = DateTime.now();
    if (_busy || now.difference(_last).inMilliseconds < 700) return;
    if (img.planes.length != 1) return;
    _busy = true;
    _last = now;
    try {
      final rotation = InputImageRotationValue.fromRawValue(cam.sensorOrientation) ??
          InputImageRotation.rotation90deg;
      final plane = img.planes.first;
      final input = InputImage.fromBytes(
        bytes: plane.bytes,
        metadata: InputImageMetadata(
          size: Size(img.width.toDouble(), img.height.toDouble()),
          rotation: rotation,
          format: InputImageFormat.nv21,
          bytesPerRow: plane.bytesPerRow,
        ),
      );
      final labels = await _labeler.processImage(input);
      _frames++;
      for (final l in labels) {
        final de = foodLabels[l.label.toLowerCase()];
        if (de == null) continue;
        _dets[de] = _Det(l.confidence, now);
      }
      if (mounted) setState(() {});
    } catch (_) {
      // einzelne Frames dürfen fehlschlagen
    } finally {
      _busy = false;
    }
  }

  @override
  void dispose() {
    _pruner?.cancel();
    _anim.dispose();
    _cam?.dispose();
    _labeler.close();
    super.dispose();
  }

  Future<void> _addAll(List<String> names) async {
    var n = 0;
    for (final name in names) {
      if (_added.add(name)) {
        await _s.addFridge(name);
        n++;
      }
    }
    if (mounted && n > 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: Pal.hudBg,
        content: Text('$n Objekt(e) im Kühlschrank registriert',
            style: const TextStyle(color: Pal.hudCyan, fontFamily: 'monospace')),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final cam = _cam;
    final locked = _dets.isNotEmpty;
    final c = locked ? Pal.hudGold : Pal.hudCyan;
    final sorted = _dets.entries.toList()..sort((a, b) => b.value.conf.compareTo(a.value.conf));
    final top = sorted.isEmpty ? null : sorted.first.key;

    return Container(
      color: Pal.hudBg,
      child: Stack(fit: StackFit.expand, children: [
        if (cam != null && cam.value.isInitialized)
          Positioned.fill(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                // previewSize ist im Querformat angegeben -> fürs Hochformat tauschen
                width: cam.value.previewSize!.height,
                height: cam.value.previewSize!.width,
                child: CameraPreview(cam),
              ),
            ),
          ),
        Positioned.fill(child: Container(color: Pal.hudBg.withOpacity(0.35))),
        Positioned.fill(child: CustomPaint(painter: HudPainter(_anim, locked, top))),
        if (_error != null)
          Center(
            child: Text(_error!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Pal.hudRed, fontFamily: 'monospace', letterSpacing: 1.5)),
          ),
        SafeArea(
          child: Column(children: [
            _topBar(c, locked),
            const Spacer(),
            _analysisPanel(c, sorted),
          ]),
        ),
      ]),
    );
  }

  Widget _topBar(Color c, bool locked) {
    final mono = TextStyle(color: c, fontFamily: 'monospace', fontSize: 11, letterSpacing: 1.6);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Column(children: [
        Row(children: [
          Icon(Icons.circle, size: 8, color: locked ? Pal.hudGold : Pal.hudCyan),
          const SizedBox(width: 8),
          Text('SYS//VISION ONLINE', style: mono),
          const Spacer(),
          Text('HH ${_s.code}', style: mono),
        ]),
        const SizedBox(height: 6),
        Row(children: [
          Text(locked ? 'STATUS: TARGET LOCKED' : 'STATUS: SCANNING...', style: mono),
          const Spacer(),
          Text('FRM ${_frames.toString().padLeft(4, '0')}  OBJ ${_dets.length}', style: mono),
        ]),
      ]),
    );
  }

  Widget _analysisPanel(Color c, List<MapEntry<String, _Det>> sorted) {
    final mono = TextStyle(color: c, fontFamily: 'monospace', fontSize: 12, letterSpacing: 1.4);
    final shown = sorted.take(4).toList();
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Pal.hudBg.withOpacity(0.78),
        border: Border.all(color: c.withOpacity(0.7)),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('> ANALYSE', style: mono.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        if (shown.isEmpty)
          Text('Halte Lebensmittel vor die Linse...', style: mono.copyWith(color: Colors.white54)),
        for (final e in shown)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(children: [
              SizedBox(width: 108, child: Text(e.key.toUpperCase(), style: mono, overflow: TextOverflow.ellipsis)),
              Expanded(
                child: LinearProgressIndicator(
                  value: e.value.conf,
                  minHeight: 5,
                  backgroundColor: c.withOpacity(0.15),
                  color: c,
                ),
              ),
              const SizedBox(width: 10),
              Text('${(e.value.conf * 100).round()}%', style: mono),
              const SizedBox(width: 4),
              InkWell(
                onTap: _added.contains(e.key) ? null : () => _addAll([e.key]),
                child: Padding(
                  padding: const EdgeInsets.all(4),
                  child: Icon(_added.contains(e.key) ? Icons.check : Icons.add_box_outlined, size: 20, color: c),
                ),
              ),
            ]),
          ),
        if (shown.isNotEmpty) ...[
          const SizedBox(height: 4),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => _addAll(shown.map((e) => e.key).toList()),
              style: OutlinedButton.styleFrom(
                foregroundColor: c,
                minimumSize: const Size.fromHeight(44),
                side: BorderSide(color: c),
                shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              ),
              child: Text('ALLE IN KÜHLSCHRANK ÜBERNEHMEN',
                  style: mono.copyWith(fontWeight: FontWeight.bold, fontSize: 11)),
            ),
          ),
        ],
      ]),
    );
  }
}

/// Zeichnet das HUD: Raster, Eck-Zielrahmen, Scan-Linie, rotierendes Fadenkreuz.
class HudPainter extends CustomPainter {
  final Animation<double> anim;
  final bool locked;
  final String? top;
  HudPainter(this.anim, this.locked, this.top) : super(repaint: anim);

  @override
  void paint(Canvas canvas, Size size) {
    final t = anim.value;
    final c = locked ? Pal.hudGold : Pal.hudCyan;
    final pulse = 0.65 + 0.35 * sin(t * 2 * pi * (locked ? 3 : 1));

    // Raster
    final grid = Paint()
      ..color = Pal.hudCyan.withOpacity(0.06)
      ..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 40) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += 40) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final frame = Rect.fromCenter(
      center: Offset(size.width / 2, size.height * 0.36),
      width: size.width * 0.78,
      height: size.height * 0.34,
    );

    // Eck-Klammern
    final corner = Paint()
      ..color = c.withOpacity(pulse)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    const l = 34.0;
    void bracket(Offset o, double dx, double dy) {
      canvas.drawPath(
        Path()
          ..moveTo(o.dx, o.dy + dy * l)
          ..lineTo(o.dx, o.dy)
          ..lineTo(o.dx + dx * l, o.dy),
        corner,
      );
    }

    bracket(frame.topLeft, 1, 1);
    bracket(frame.topRight, -1, 1);
    bracket(frame.bottomLeft, 1, -1);
    bracket(frame.bottomRight, -1, -1);

    // Scan-Linie (Ping-Pong)
    final k = (sin(t * 2 * pi) + 1) / 2;
    final y = frame.top + frame.height * k;
    final band = Rect.fromLTWH(frame.left, y - 22, frame.width, 44);
    canvas.drawRect(
      band,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [c.withOpacity(0), c.withOpacity(0.35), c.withOpacity(0)],
        ).createShader(band),
    );
    canvas.drawLine(
      Offset(frame.left, y),
      Offset(frame.right, y),
      Paint()
        ..color = c
        ..strokeWidth = 1.5,
    );

    // Rotierendes Fadenkreuz
    final ctr = frame.center;
    final ring = Paint()
      ..color = c.withOpacity(0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    final a = t * 2 * pi;
    for (var i = 0; i < 4; i++) {
      canvas.drawArc(Rect.fromCircle(center: ctr, radius: 40), a + i * pi / 2, pi / 3, false, ring);
      canvas.drawArc(Rect.fromCircle(center: ctr, radius: 24), -a * 1.5 + i * pi / 2, pi / 5, false, ring);
    }
    final cross = Paint()
      ..color = c.withOpacity(0.7)
      ..strokeWidth = 1;
    canvas.drawLine(ctr.translate(-58, 0), ctr.translate(-46, 0), cross);
    canvas.drawLine(ctr.translate(46, 0), ctr.translate(58, 0), cross);
    canvas.drawLine(ctr.translate(0, -58), ctr.translate(0, -46), cross);
    canvas.drawLine(ctr.translate(0, 46), ctr.translate(0, 58), cross);

    // Seitliche Skala
    for (var i = 0; i <= 10; i++) {
      final yy = frame.top + frame.height * i / 10;
      canvas.drawLine(
        Offset(frame.left - 12, yy),
        Offset(frame.left - (i % 5 == 0 ? 2 : 7), yy),
        cross,
      );
    }

    // Beschriftungen
    _text(canvas, 'FOOD-NET // ML', frame.bottomLeft.translate(0, 8), c.withOpacity(0.8), 10);
    if (top != null) {
      _text(canvas, '▸ ${top!.toUpperCase()}', frame.topLeft.translate(0, -22), c, 14, bold: true);
    }
  }

  void _text(Canvas canvas, String s, Offset o, Color color, double size, {bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(
        text: s,
        style: TextStyle(
          color: color,
          fontSize: size,
          fontFamily: 'monospace',
          letterSpacing: 1.6,
          fontWeight: bold ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, o);
  }

  @override
  bool shouldRepaint(HudPainter old) => old.locked != locked || old.top != top;
}
